package com.aria.assistant

import android.Manifest
import android.app.Activity
import android.app.KeyguardManager
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.os.Bundle
import android.provider.Settings
import android.speech.RecognizerIntent
import android.text.InputType
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private lateinit var out: TextView
    private lateinit var scroll: ScrollView
    private lateinit var root: LinearLayout
    private lateinit var assistant: Assistant

    private var unlocked = false
    private var authInProgress = false
    private var lastStop = 0L

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun append(s: String) {
        out.append(s + "\n\n")
        scroll.post { scroll.fullScroll(ScrollView.FOCUS_DOWN) }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Speaker.init(this)
        val prefs = getSharedPreferences("aria", MODE_PRIVATE)

        assistant = Assistant(this) { display, spoken ->
            append("Aria: $display")
            Speaker.speak(spoken)
        }

        val match = ViewGroup.LayoutParams.MATCH_PARENT
        val wrap = ViewGroup.LayoutParams.WRAP_CONTENT

        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(40), dp(16), dp(16))
            setBackgroundColor(Color.WHITE)
        }

        root.addView(TextView(this).apply {
            text = "Aria"
            textSize = 30f
            setTextColor(Color.parseColor("#7B1FA2"))
        })

        // API key row
        val keyRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val keyBox = EditText(this).apply {
            hint = "Paste AI API key (optional)"
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
            setText(prefs.getString("apikey", ""))
            setSingleLine(true)
        }
        keyRow.addView(keyBox, LinearLayout.LayoutParams(0, wrap, 1f))
        keyRow.addView(Button(this).apply {
            text = "Save"
            setOnClickListener {
                prefs.edit().putString("apikey", keyBox.text.toString().trim()).apply()
                Toast.makeText(this@MainActivity, "Saved", Toast.LENGTH_SHORT).show()
            }
        })
        root.addView(keyRow, LinearLayout.LayoutParams(match, wrap))

        // Secret wake phrase row
        val wakeRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val wakeBox = EditText(this).apply {
            hint = "Secret phrase (optional)"
            setText(prefs.getString("wake", ""))
            setSingleLine(true)
        }
        wakeRow.addView(wakeBox, LinearLayout.LayoutParams(0, wrap, 1f))
        wakeRow.addView(Button(this).apply {
            text = "Save"
            setOnClickListener {
                prefs.edit().putString("wake", wakeBox.text.toString().trim()).apply()
                Toast.makeText(this@MainActivity, "Saved", Toast.LENGTH_SHORT).show()
            }
        })
        root.addView(wakeRow, LinearLayout.LayoutParams(match, wrap))

        root.addView(Switch(this).apply {
            text = "Read new messages aloud"
            isChecked = prefs.getBoolean("autoread", false)
            setOnCheckedChangeListener { _, checked ->
                prefs.edit().putBoolean("autoread", checked).apply()
            }
        }, LinearLayout.LayoutParams(match, wrap).apply { topMargin = dp(8) })

        root.addView(Button(this).apply {
            text = "Change Aria's voice"
            setOnClickListener {
                val info = Speaker.nextVoice()
                Toast.makeText(this@MainActivity, info, Toast.LENGTH_SHORT).show()
            }
        }, LinearLayout.LayoutParams(match, wrap))

        root.addView(Button(this).apply {
            text = "Turn on notification access"
            setOnClickListener { startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)) }
        }, LinearLayout.LayoutParams(match, wrap))

        root.addView(Button(this).apply {
            text = "TAP TO TALK"
            textSize = 20f
            setOnClickListener { listen() }
        }, LinearLayout.LayoutParams(match, dp(80)).apply { topMargin = dp(8) })

        // Typing row
        val typeRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val cmdBox = EditText(this).apply {
            hint = "...or type a command"
            setSingleLine(true)
        }
        typeRow.addView(cmdBox, LinearLayout.LayoutParams(0, wrap, 1f))
        typeRow.addView(Button(this).apply {
            text = "Send"
            setOnClickListener {
                val t = cmdBox.text.toString()
                if (t.isNotBlank()) {
                    cmdBox.setText("")
                    run(t)
                }
            }
        })
        root.addView(typeRow, LinearLayout.LayoutParams(match, wrap))

        scroll = ScrollView(this)
        out = TextView(this).apply {
            textSize = 16f
            setTextColor(Color.BLACK)
            setTextIsSelectable(true)
        }
        scroll.addView(out)
        root.addView(scroll, LinearLayout.LayoutParams(match, 0, 1f).apply { topMargin = dp(8) })

        setContentView(root)

        append("Aria: Hi! Tap the button and say a command, like \"read my messages\", \"call Mom\", or \"reply to Sam saying I'm on my way\".")
        Speaker.speak("Hello, I'm Aria. How can I help?")

        askPermissions()
        requireUnlock()
    }

    // ---- Lock: uses the phone's own fingerprint / PIN / pattern ----

    private fun requireUnlock() {
        val prefs = getSharedPreferences("aria", MODE_PRIVATE)
        val km = getSystemService(KeyguardManager::class.java)
        if (!false || km == null || !km.isDeviceSecure) {
            unlocked = true
            root.visibility = View.VISIBLE
            return
        }
        root.visibility = View.INVISIBLE
        val intent = km.createConfirmDeviceCredentialIntent("Aria", "Unlock to use Aria")
        if (intent == null) {
            unlocked = true
            root.visibility = View.VISIBLE
            return
        }
        authInProgress = true
        startActivityForResult(intent, 3)
    }

    override fun onStop() {
        super.onStop()
        lastStop = System.currentTimeMillis()
    }

    override fun onResume() {
        super.onResume()
        if (!::root.isInitialized || authInProgress) return
        if (unlocked && lastStop > 0 && System.currentTimeMillis() - lastStop > 120_000) {
            unlocked = false
        }
        if (!unlocked) requireUnlock()
    }

    private fun askPermissions() {
        val perms = arrayOf(
            Manifest.permission.CALL_PHONE,
            Manifest.permission.SEND_SMS,
            Manifest.permission.READ_CONTACTS,
            Manifest.permission.ANSWER_PHONE_CALLS
        )
        val missing = perms.filter { checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED }
        if (missing.isNotEmpty()) requestPermissions(missing.toTypedArray(), 2)
    }

    private fun run(command: String) {
        append("You: $command")
        assistant.handle(command)
    }

    /** If a secret phrase is set, spoken commands must start with it. Returns the command, or null to ignore. */
    private fun gate(spoken: String): String? {
        val wake = getSharedPreferences("aria", MODE_PRIVATE).getString("wake", "")?.trim() ?: ""
        if (wake.isEmpty()) return spoken
        val s = spoken.trim()
        if (!s.startsWith(wake, ignoreCase = true)) return null
        return s.substring(wake.length).trim().trimStart(',', '.', ' ')
    }

    private fun listen() {
        Speaker.stop()
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_PROMPT, "Speak now")
        }
        try {
            startActivityForResult(i, 1)
        } catch (e: Exception) {
            Toast.makeText(this, "Voice input is not available on this phone.", Toast.LENGTH_LONG).show()
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 3) {
            authInProgress = false
            if (resultCode == RESULT_OK) {
                unlocked = true
                root.visibility = View.VISIBLE
            } else {
                finish()
            }
            return
        }
        if (requestCode == 1 && resultCode == RESULT_OK) {
            val spoken = data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull() ?: return
            val command = gate(spoken)
            if (command == null) {
                append("Aria: I didn't hear the secret phrase, so I ignored that.")
            } else if (command.isNotBlank()) {
                run(command)
            }
        }
    }
}
