package com.aria.assistant

import android.content.Context
import android.speech.tts.TextToSpeech
import android.speech.tts.Voice
import java.util.Locale
import java.util.UUID

object Speaker {
    private var tts: TextToSpeech? = null
    private var ready = false
    private var appCtx: Context? = null
    private var voices: List<Voice> = emptyList()
    private var idx = -1
    private val pending = mutableListOf<String>()

    fun init(ctx: Context) {
        if (tts != null) return
        appCtx = ctx.applicationContext
        tts = TextToSpeech(ctx.applicationContext) { status ->
            val t = tts
            if (status == TextToSpeech.SUCCESS && t != null) {
                t.setLanguage(Locale.US)
                val all = try { t.voices?.toList() ?: emptyList() } catch (e: Exception) { emptyList() }
                voices = all.filter { it.locale.language == "en" }.sortedBy { it.name }

                val saved = appCtx?.getSharedPreferences("aria", Context.MODE_PRIVATE)?.getString("voice", null)
                val chosen = voices.firstOrNull { it.name == saved }
                    ?: voices.firstOrNull { it.name.contains("female", true) }
                    ?: voices.firstOrNull { v -> listOf("-tpf-", "-sfg-", "-iog-").any { v.name.contains(it) } }
                if (chosen != null) {
                    t.setVoice(chosen)
                    idx = voices.indexOf(chosen)
                }
                val knownFemale = chosen != null && (chosen.name.contains("female", true) ||
                    listOf("-tpf-", "-sfg-", "-iog-").any { chosen.name.contains(it) })
                t.setPitch(if (knownFemale) 1.1f else 1.3f)
                ready = true
                pending.forEach { t.speak(it, TextToSpeech.QUEUE_ADD, null, UUID.randomUUID().toString()) }
                pending.clear()
            }
        }
    }

    fun speak(text: String) {
        val t = tts
        if (ready && t != null) {
            t.speak(text, TextToSpeech.QUEUE_ADD, null, UUID.randomUUID().toString())
        } else {
            pending.add(text)
        }
    }

    /** Switch to the next installed English voice and say a sample. */
    fun nextVoice(): String {
        val t = tts
        if (!ready || t == null || voices.isEmpty()) return "No other voices found on this phone."
        idx = (idx + 1) % voices.size
        val v = voices[idx]
        t.setVoice(v)
        appCtx?.getSharedPreferences("aria", Context.MODE_PRIVATE)?.edit()?.putString("voice", v.name)?.apply()
        t.speak("Hello, this is my voice. Do you like it?", TextToSpeech.QUEUE_FLUSH, null, UUID.randomUUID().toString())
        return "Voice ${idx + 1} of ${voices.size}"
    }

    fun stop() {
        tts?.stop()
    }
}
