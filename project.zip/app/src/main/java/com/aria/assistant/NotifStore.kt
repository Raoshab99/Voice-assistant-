package com.aria.assistant

import android.app.Notification

data class NotifItem(
    val key: String,
    val pkg: String,
    val app: String,
    val title: String,
    val text: String,
    val action: Notification.Action?
)

object NotifStore {
    private val items = mutableListOf<NotifItem>()

    @Synchronized
    fun add(item: NotifItem) {
        items.removeAll { it.key == item.key }
        items.add(0, item)
        while (items.size > 25) items.removeAt(items.size - 1)
    }

    @Synchronized
    fun snapshot(): List<NotifItem> = items.toList()
}
