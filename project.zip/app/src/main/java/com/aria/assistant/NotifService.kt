package com.aria.assistant

import android.app.Notification
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

class NotifService : NotificationListenerService() {

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        if (sbn.packageName == packageName) return
        val n = sbn.notification
        if ((n.flags and Notification.FLAG_GROUP_SUMMARY) != 0) return
        if (sbn.isOngoing) return

        val extras = n.extras
        val title = extras.getCharSequence(Notification.EXTRA_TITLE)?.toString() ?: return
        val text = extras.getCharSequence(Notification.EXTRA_TEXT)?.toString() ?: return

        val isMessage = n.category == Notification.CATEGORY_MESSAGE
        val action = n.actions?.firstOrNull { a -> a.remoteInputs?.isNotEmpty() == true }
        if (!isMessage && action == null) return

        val app = try {
            packageManager.getApplicationLabel(packageManager.getApplicationInfo(sbn.packageName, 0)).toString()
        } catch (e: Exception) {
            sbn.packageName
        }

        NotifStore.add(NotifItem(sbn.key, sbn.packageName, app, title, text, action))

        val prefs = getSharedPreferences("aria", MODE_PRIVATE)
        if (prefs.getBoolean("autoread", false)) {
            Speaker.init(this)
            Speaker.speak("New message from $title on $app. ${text.take(300)}")
        }
    }
}
