package com.aria.assistant

import android.Manifest
import android.app.RemoteInput
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.ContactsContract
import android.telecom.TelecomManager
import android.telephony.SmsManager
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

class Assistant(
    private val ctx: Context,
    private val say: (String, String) -> Unit
) {
    private val main = Handler(Looper.getMainLooper())
    private val history = mutableListOf<Pair<String, String>>()

    private val reReply = Regex("^reply(?: to (.+?))? (?:saying|say|that|with) (.+)$", RegexOption.IGNORE_CASE)
    private val reReplyPlain = Regex("^reply (.+)$", RegexOption.IGNORE_CASE)
    private val reSend = Regex(
        "^(?:send (?:a )?(?:message |text |sms )?to|text|sms|message|whatsapp|telegram) (.+?) (?:saying|say|that|with) (.+)$",
        RegexOption.IGNORE_CASE
    )
    private val reCall = Regex("^(?:call|phone|dial|ring) (.+)$", RegexOption.IGNORE_CASE)

    private fun reply(display: String, spoken: String = display) = say(display, spoken)

    private fun has(perm: String) =
        ctx.checkSelfPermission(perm) == PackageManager.PERMISSION_GRANTED

    fun handle(raw: String) {
        val text = raw.trim().trimEnd('.', '!', '?')
        val t = text.lowercase()
        if (t.isEmpty()) return

        when {
            t == "stop" || t == "be quiet" -> Speaker.stop()

            reReply.matches(text) -> {
                val m = reReply.find(text)!!
                val name = m.groupValues[1].ifBlank { null }
                replyToNotification(name, m.groupValues[2])
            }

            reSend.matches(text) -> {
                val m = reSend.find(text)!!
                sendMessage(m.groupValues[1], m.groupValues[2])
            }

            reReplyPlain.matches(text) -> {
                val m = reReplyPlain.find(text)!!
                replyToNotification(null, m.groupValues[1])
            }

            listOf("end call", "cut call", "hang up", "disconnect", "decline call", "reject call").any { t.contains(it) } ->
                endCall()

            t.contains("answer") && (t.contains("call") || t.contains("phone") || t == "answer") ->
                answerCall()

            reCall.matches(text) -> {
                val m = reCall.find(text)!!
                placeCall(m.groupValues[1])
            }

            isReadRequest(t) -> readMessages()

            else -> askAi(text)
        }
    }

    private fun isReadRequest(t: String): Boolean {
        val about = t.contains("message") || t.contains("notification")
        if (!about) return false
        return t.startsWith("read") || t.startsWith("check") || t.contains("any new") ||
            t.contains("my messages") || t.contains("my notifications") ||
            t.contains("what are my") || t.contains("do i have")
    }

    private fun readMessages() {
        val list = NotifStore.snapshot().take(5)
        if (list.isEmpty()) {
            reply("You have no new messages. If this seems wrong, make sure notification access is turned on for me.")
            return
        }
        val shown = list.joinToString("\n") { "${it.app} - ${it.title}: ${it.text}" }
        val spoken = list.joinToString(". ") { "From ${it.title} on ${it.app}: ${it.text.take(200)}" }
        reply(shown, "You have ${list.size} recent messages. $spoken")
    }

    // ---- Replying in any app through the notification's reply button ----

    private fun findNotification(name: String?): NotifItem? =
        NotifStore.snapshot().firstOrNull {
            it.action != null && (name == null || it.title.contains(name, ignoreCase = true))
        }

    private fun sendNotificationReply(item: NotifItem, msg: String): Boolean {
        val action = item.action ?: return false
        val inputs = action.remoteInputs ?: return false
        if (inputs.isEmpty()) return false
        return try {
            val intent = Intent()
            val bundle = Bundle()
            bundle.putCharSequence(inputs[0].resultKey, msg)
            RemoteInput.addResultsToIntent(inputs, intent, bundle)
            action.actionIntent.send(ctx, 0, intent)
            true
        } catch (e: Exception) {
            false
        }
    }

    private fun replyToNotification(name: String?, msg: String) {
        val item = findNotification(name)
        if (item == null) {
            reply("I couldn't find a recent chat to reply to.")
            return
        }
        if (sendNotificationReply(item, msg)) {
            reply("Replied to ${item.title} on ${item.app}: $msg", "Done. I replied to ${item.title}.")
        } else {
            reply("Sorry, I couldn't send that reply.")
        }
    }

    // ---- Messages: chat app reply if possible, otherwise SMS ----

    private fun sendMessage(name: String, msg: String) {
        val item = findNotification(name)
        if (item != null && sendNotificationReply(item, msg)) {
            reply("Sent to ${item.title} on ${item.app}: $msg", "Done. I sent your message to ${item.title} on ${item.app}.")
            return
        }
        sendSms(name, msg)
    }

    private fun sendSms(target: String, msg: String) {
        if (!has(Manifest.permission.SEND_SMS)) {
            reply("I need permission to send SMS. Please allow it in the app settings.")
            return
        }
        val number = resolveNumber(target)
        if (number == null) {
            reply("I couldn't find a phone number for $target.")
            return
        }
        try {
            val sms = if (Build.VERSION.SDK_INT >= 31) {
                ctx.getSystemService(SmsManager::class.java)
            } else {
                @Suppress("DEPRECATION") SmsManager.getDefault()
            }
            sms.sendMultipartTextMessage(number, null, sms.divideMessage(msg), null, null)
            reply("SMS sent to $target: $msg", "Done. I sent a text message to $target.")
        } catch (e: Exception) {
            reply("Sorry, the message could not be sent.")
        }
    }

    private fun resolveNumber(target: String): String? {
        val digits = target.filter { it.isDigit() || it == '+' }
        if (digits.length >= 6 && target.none { it.isLetter() }) return digits
        if (!has(Manifest.permission.READ_CONTACTS)) return null
        val cursor = ctx.contentResolver.query(
            ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
            arrayOf(ContactsContract.CommonDataKinds.Phone.NUMBER),
            "${ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME} LIKE ?",
            arrayOf("%$target%"),
            null
        )
        cursor?.use {
            if (it.moveToFirst()) return it.getString(0)
        }
        return null
    }

    // ---- Calls ----

    private fun placeCall(target: String) {
        if (!has(Manifest.permission.CALL_PHONE)) {
            reply("I need permission to make calls. Please allow it in the app settings.")
            return
        }
        val number = resolveNumber(target)
        if (number == null) {
            reply("I couldn't find a number for $target.")
            return
        }
        try {
            val i = Intent(Intent.ACTION_CALL, Uri.parse("tel:" + Uri.encode(number)))
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            ctx.startActivity(i)
            reply("Calling $target", "Calling $target now.")
        } catch (e: Exception) {
            reply("Sorry, I couldn't place the call.")
        }
    }

    private fun answerCall() {
        if (!has(Manifest.permission.ANSWER_PHONE_CALLS)) {
            reply("I need permission to answer calls. Please allow it in the app settings.")
            return
        }
        try {
            ctx.getSystemService(TelecomManager::class.java).acceptRingingCall()
            reply("Answering the call.")
        } catch (e: Exception) {
            reply("Sorry, I couldn't answer the call.")
        }
    }

    private fun endCall() {
        if (!has(Manifest.permission.ANSWER_PHONE_CALLS)) {
            reply("I need permission to end calls. Please allow it in the app settings.")
            return
        }
        try {
            if (Build.VERSION.SDK_INT >= 28) {
                val ok = ctx.getSystemService(TelecomManager::class.java).endCall()
                reply(if (ok) "Call ended." else "There is no active call to end.")
            } else {
                reply("Ending calls needs Android 9 or newer.")
            }
        } catch (e: Exception) {
            reply("Sorry, I couldn't end the call.")
        }
    }

    // ---- AI help (questions, code, websites) ----

    private fun askAi(question: String) {
        val prefs = ctx.getSharedPreferences("aria", Context.MODE_PRIVATE)
        val key = prefs.getString("apikey", "") ?: ""
        if (key.isBlank()) {
            reply("To answer that I need an AI key. Paste it in the box at the top and tap Save.")
            return
        }
        reply("One moment...", "One moment.")
        val past = history.toList()
        Thread {
            try {
                val msgs = JSONArray()
                past.forEach { (role, content) ->
                    msgs.put(JSONObject().put("role", role).put("content", content))
                }
                msgs.put(JSONObject().put("role", "user").put("content", question))

                val body = JSONObject()
                    .put("model", "claude-sonnet-5-5")
                    .put("max_tokens", 2000)
                    .put(
                        "system",
                        "You are Aria, a friendly female voice assistant on an Android phone. " +
                            "Answer briefly and conversationally. If asked for code or a website, give one " +
                            "short friendly sentence, then the complete working code in a fenced code block."
                    )
                    .put("messages", msgs)

                val conn = URL("https://api.anthropic.com/v1/messages").openConnection() as HttpURLConnection
                conn.requestMethod = "POST"
                conn.connectTimeout = 20000
                conn.readTimeout = 90000
                conn.doOutput = true
                conn.setRequestProperty("x-api-key", key)
                conn.setRequestProperty("anthropic-version", "2023-06-01")
                conn.setRequestProperty("content-type", "application/json")
                conn.outputStream.use { it.write(body.toString().toByteArray()) }

                val code = conn.responseCode
                val stream = if (code in 200..299) conn.inputStream else conn.errorStream
                val resp = stream.bufferedReader().readText()

                if (code !in 200..299) {
                    main.post { reply("The AI service returned error $code.\n$resp", "Sorry, the AI service returned an error.") }
                } else {
                    val arr = JSONObject(resp).getJSONArray("content")
                    val sb = StringBuilder()
                    for (i in 0 until arr.length()) {
                        val block = arr.getJSONObject(i)
                        if (block.optString("type") == "text") sb.append(block.getString("text"))
                    }
                    val full = sb.toString()
                    val spoken = full
                        .replace(Regex("```[\\s\\S]*?```"), " The code is on your screen. ")
                        .replace("*", "")
                        .replace("#", "")
                        .take(400)
                    main.post {
                        history.add("user" to question)
                        history.add("assistant" to full)
                        while (history.size > 10) history.removeAt(0)
                        reply(full, spoken)
                    }
                }
            } catch (e: Exception) {
                main.post { reply("I couldn't reach the AI. Check your internet connection and API key.") }
            }
        }.start()
    }
}
